import Vue from 'vue'
import Router from 'vue-router'
import CryoHome from '@/components/CryoHome'
import Faq from '@/components/Faq'
import Register from '@/components/Register'
import Account from '@/components/Account'
import UserInfo from '@/components/UserInfo'
import Apply from '@/components/Apply'
import CryoInfo from '@/components/CryoInfo'
// links routed
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'CryoHome',
      component: CryoHome
    },
    {
      path: '/faq',
      name: 'Faq',
      component: Faq
    },
    {
      path: '/reg',
      name: 'Register',
      component: Register
    },
    {
      path: '/acc',
      name: 'Account',
      component: Account
    },
    {
      path: '/userinfo',
      name: 'UserInfo',
      component: UserInfo
    },
    {
      path: '/apply',
      name: 'Apply',
      component: Apply
    },
    {
      path: '/cryoinfo',
      name: 'CryoInfo',
      component: CryoInfo
    }
  ]
})
