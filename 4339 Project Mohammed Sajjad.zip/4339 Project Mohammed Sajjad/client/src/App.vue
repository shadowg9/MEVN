<template>
  <div id="app">
    <Navbar/>
     <img src="./assets/future.png">
    <router-view/>
    <Footer/>
  </div>
  <!-- main page that displays the website -->
</template>

<script>
import Navbar from './components/Navbar'
import Footer from './components/Footer'
export default {
  name: 'App',
  components:{
    Navbar,
    Footer
  }
}
</script>

<style>

body {
    background-color: rgb(227, 247, 248);
}

img {
  margin-left: auto;
  margin-right: auto; 
  display: block;
}

</style>
