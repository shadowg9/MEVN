import axios from 'axios';

const url = 'http://localhost:3001/';

class userServices {
    static login(participant) {
        return new Promise(async(resolve, reject) => {
            try {
                const res = await axios.post('${url}login', {participant});
                const data = res.data
                console.log(data)
                resolve(data)
            } catch (error) {
                reject('Invalid Credentials');
            }
        })
    }

    static register(participant) {
        return new Promise(async (resolve, reject) => {
            try{
                const res = await axios.post('${url}register', {participant})
                const data = res.data
                console.log(data)
                resolve(data)
            } catch(error){
                reject("Unable to Register");
            }
        })
    }
}

//This page is referenced to the class lecture from 11/11/20

export default userServices; 