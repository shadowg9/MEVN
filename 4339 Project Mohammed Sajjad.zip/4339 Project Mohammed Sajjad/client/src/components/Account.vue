<template>
 <div>
    <h1>Login</h1>
    <form @submit.prevent="login">
        <fieldset>
            <legend>Login Required</legend>

          

            <label>Email:</label>
            <input type="text"  />
            <br>
            <br>

            <label>Password:</label>
            <input type="password" />
            <br>
            <br>

           

            <input type="submit" value="Login">
        </fieldset>
    </form>
</div>
</template>

<script>
import userServices from '../userServices'
export default {
    name: "Home",
    data() {
        return {
            user: {
                email:'',
                password:''
            },
            status: null
        }
    },
    methods: {
        async login() {
            try{
                const participantFound = userServices.login(this.user).then(participant =>{
                    this.status = null
                    console.log(participantFound)
                    this.storeToken(participant.foundUser)
                    return participant
                }).catch((error)=>{
                    this.status = error
                })
            }catch(error){
                this.status = error
            }
        }
    }
    //This page is referenced to the class lecture from 11/11/20

}
</script>