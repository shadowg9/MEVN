
<template>
  <div class="cryo">
     

    <h3>Introduction</h3>
    <p> Aion Cryonic Services is a research organization that's tailored to the idea of immortality.
       The name of the company is inspired by the Hellenistic God of time known as Aion. 
       The research in our facility is dedicated to finding the secrets to immortality and allowing people to live in a different timeline from the one they reside in now.
        Cryonics is essentially the process of freezing bodies in hopes or reviving them in the future.  </p>
    <h3>Mission Statement</h3>
    <p>The goal of Aion Cryonic Services is to fulfill the desire of living in a utopian future free from the ill wills that shrouds our well being. 
      Individuals will have a chance to start over in a society that has exponetially progressed to higher ideals and motives. </p>
    <h3>Things to Consider</h3>
    <p>Know that when you fully go through with this, that you might not come back. This isn't a choice to be made impulsively and people must recognizt the gravity of the situtation.
      The starting date to be frozen is 2060, but is still subject to change. A minimum of 40 years is required when deciding to be frozen, otherwise the whole purpose of the choice would be futile.
      All questions will be answered in the FAQ page.
    </p>
  </div>

  <!-- This page displays the bulk of the idea presented to the viewers -->
</template>




<style scoped>

h3 {
  text-align: center;
  color: #52b7bb;
}

p{
  text-align: center;
}



</style>
