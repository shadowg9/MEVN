<template>
    <div>
        <h1>Register</h1>
        <form>
        <fieldset>
            <legend>Enter Information to Register</legend>

           

            <label>First Name:</label>
            <input v-model="user.firstName" type="text" placeholder="Enter First Name" />
            <br>
            <br>

            <label>Last Name:</label>
            <input type="text" v-model="user.lastName" placeholder="Enter Last Name"/>
            <br>
            <br>

            <label>Date of Birth:</label>
            <input type="date" v-model="user.dateofBirth" placeholder="Enter Date of Birth" />
            <br>
            <br>

            <label>Sex:</label>
             <input type="radio" v-model="user.sex" id="male" name="sex" value="Male">
             <label for='male'>Male</label>
             <input type="radio" v-model="user.sex" id="female" name="sex" value="Female">  
             <label for='female'>Female</label>
            <br>
            <br>

                
             <!-- Link above is the reference page I used to assist me with the Radio Buttons -->
             <!-- https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_radio -->

            <label>Email:</label>
            <input type="text" v-model="user.email" placeholder="Enter Email" />
            <br>
            <br>

            <label>Password:</label>
            <input type="password" v-model="user.password" placeholder="Enter Password" />
            <br>
            <br>

              <!-- this is the form used to input data for the userLogin collection in the Cryo database -->

        
            <input type="submit" @click="add"  value="Register">
        </fieldset>
    </form>
  
    </div>
</template>
<script>

import axios from 'axios'
export default {

    name: "Register",
    data() {
        return {
            user: {
                firstName: null,
                lastName: null,
                dateofBirth: null,
                sex: null,
                email: null,
                password: null
            },
           
        }
    },
    methods: {
        add(){
              // the add method allows the submit button within the form to submit information to MongoDB
            let newUser = {
                firstName: this.user.firstName,
                lastName: this.user.lastName,
                dateofBirth: this.user.dateofBirth,
                sex: this.user.sex,
                email: this.user.email,
                password: this.user.password
            }
            console.log(newUser)
            axios.post('http://localhost:3001/register', newUser)
        .then((response) => {
        console.log(response);
        })
.catch((error) => {
console.log(error);
});
        }

    
 
   
    }
}

</script>