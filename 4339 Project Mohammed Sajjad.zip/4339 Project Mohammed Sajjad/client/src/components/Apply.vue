<template>
    <div>
        <h1>Apply To Be Cryogenically Frozen!</h1>
        <form>
        <fieldset>
            <legend>Apply to Conquer Time</legend>


             <label>First Name:</label>
            <input  type="text" v-model="cryo.firstName" placeholder="Enter First Name" />
            <br>
            <br>

            <label>Last Name:</label>
            <input type="text" v-model="cryo.lastName" placeholder="Enter Last Name"/>
            <br>
            <br>


            <label>Email:</label>
            <input type="text" v-model="cryo.email" placeholder="Enter Email" />
            <br>
            <br>

            <label>Password:</label>
            <input type="password" v-model="cryo.password" placeholder="Enter Password" />
            <br>
            <br>
            
            <label>Time Frozen</label>
            <br>
            <label>Starting Date:</label>
            <input type="date"  min="2060-01-01" v-model="cryo.startingDate" placeholder="Enter Starting Date" />
            <br>
            <br>
            <label>Ending Date:</label>
            <input type="date"  min="2100-01-01" v-model="cryo.endingDate" placeholder="Enter Ending Date" />
            <br>
            <br>

             <!-- this is the form used to input data for the cryoData collection in the Cryo database -->
             


        
            <input type="submit" @click="add2" value="Apply">
        </fieldset>
    </form>

    </div>
</template>

<script>
import axios from 'axios'
export default {

    name: "Apply",
    data() {
        return {
            cryo: {
                firstName: null,
                lastName: null,
                email: null,
                password: null,
                startingDate: null,
                endingDate: null
            },
           
        }
    },
    methods: {
        // the add2 method allows the submit button within the form to submit information to MongoDB
        add2(){
            let newCryo = {
                firstName: this.cryo.firstName,
                lastName: this.cryo.lastName,
                email: this.cryo.email,
                password: this.cryo.password,
                startingDate: this.cryo.startingDate,
                endingDate: this.cryo.endingDate
            }
            console.log(newCryo)
            axios.post('http://localhost:3001/apply', newCryo)
        .then((response) => {
        console.log(response);
        }).catch((error) => {
            console.log(error);
});
        }
    }
}

</script>
