<template>
  <div class="faq">
    <h2>Frequently Asked Questions</h2>
    <h3>What is cryonics?</h3>
    <p>Cryonics is essentially the process of freezing a body and a form of psychological time travel where the participaint will wake up in the far future.</p>
    <h3>Is cryonics moral?</h3>
    <p>There is a misconception that cryonics is ressurecting the dead, which is looked down by many religions.
      Cryonics is instead a type of life support that temporarily suspends body animation until the scheduled date of reanimation. 
    </p>
    <h3>How much is all this?</h3>
    <p>The price can range anywhere from $30,000 to $200,000 depending on how long you want to be frozen.</p>
    <h3>What if we apply, but change our minds later?</h3>
    <p>The good news is we don't expect cash until the date you chose to start. Even by then we'll contact you to see if 
      you're still up for the offer. So there is no pressure or obligation involved when applying to be cryogenically frozen in the near future. 
    </p>
    <h3>Why is the starting date for the application so far away?</h3>
    <p>The reason the starting date is 2060 is because by then, the idea will become more acceptable and a legal form of treatment.</p>
    <h2>Project Questions</h2>
    <p>(full user guide is in technical document)</p>
    <h3>How to install node modules?</h3>
    <p>To install the node modlules, type in "npm install" in the terminal for both the client and server folders.</p>
    <h3>How to run frontend and backend?</h3>
    <p>To run the frontend/client side, type in "npm run dev" in the terminal. To run the backend/server side, type in "nodemon app.js".
      Make sure to cd server, then cd src, before you type in "nodemon app.js".
    </p>
    <h3>Why are the tables empty?</h3>
    <p>The user information tables will populate when you register and the cryo information tables will populate when you apply.</p>
    <h3>Do I have to create the database and collections?</h3>
    <p>The database and collections should automatically be created when filling out the forms.
       In a case where it doesn't, create a database named Cryo and two collections named userLogin and cryoData.</p>
    
    
  </div>
  <!-- this is the page that'll help users with potential questions they may have related to the topic at hand 

and is also a project guide, which will also be included in the technical document -->
</template>



