<template>
   <div>

  {{cryoData}}
 <table>
  <tr>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>Password</th>
    <th>Starting Date</th>
    <th>Ending Date</th>
  </tr>
 <tr  v-for="(list, index) in cryo" :key="index">
   <td>{{list.firstName}}</td>
   <td>{{list.lastName}}</td>
   <td>{{list.email}}</td>
   <td>{{list.password}}</td>
   <td>{{list.startingDate}}</td>
   <td>{{list.endingDate}}</td>
 

    <!-- the table displays the collection data onto the web page -->
  
   
  </tr>

</table>

</div>
</template>
<script>
import axios from 'axios'
export default {
    name: 'CryoInfo',
    data(){
        return {
            cryo: []
        }
    },
    created(){
      axios.get('http://localhost:3001/cryo').then(response =>{
            this.cryo = response.data;
        }).catch((error) => {
          console.log(error);
        })
  }
}
</script>
<style scoped>

table, th, td {
  border: 1px solid black;
}
</style>
