<template>
   <div>

  {{userLogin}}
 <table>
  <tr>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Date of Birth</th>
    <th>Sex</th>
    <th>Email</th>
    <th>Password</th>
  </tr>
 <tr  v-for="(list, index) in users" :key="index">
   <td>{{list.firstName}}</td>
   <td>{{list.lastName}}</td>
   <td>{{list.dateofBirth}}</td>
   <td>{{list.sex}}</td>
   <td>{{list.email}}</td>
   <td>{{list.password}}</td>

   <!-- the table displays the collection data onto the web page -->
   
  </tr>

</table>

</div>
</template>
<script>
import axios from 'axios'
export default {
    name: 'UserInfo',
    data(){
        return {
            users: []
        }
    },
    created(){
      axios.get('http://localhost:3001/').then(response =>{
            this.users = response.data;
        }).catch((error) => {
          console.log(error);
        })
  }
}
</script>
<style scoped>
/* Link below is the reference page I used to assist me with the Table Border */
/* https://www.w3schools.com/css/css_table.asp */
table, th, td {
  border: 1px solid black;
}
</style>
