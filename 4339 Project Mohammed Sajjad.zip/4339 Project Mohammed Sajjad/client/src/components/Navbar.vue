<template>
    <div class='nav'>
        <ul>
        <li><router-link to="/" id="tab">Home</router-link></li>
        <li><router-link to="/reg" id="tab">Registration</router-link></li>
        <li><router-link to="/acc" id="tab">Account</router-link></li>
        <li><router-link to="/apply" id="tab">Apply</router-link></li>
        <li><router-link to="/faq" id="tab">FAQ</router-link></li>
        <li><router-link to="/userinfo" id="tab">User Information</router-link></li>
        <li><router-link to="/cryoinfo" id="tab">Cryonics Information</router-link></li>
        <!-- This page is referenced to the class lecture from 11/11/20 -->
    </ul>
        <h1>Aion Cryonic Services</h1>
        <h2>CONQUERING TIME</h2>
        <!-- <img src="./future.jpg"> -->
        
  
    </div>
</template>

<style scoped>
ul {
    list-style-type: none;
    padding: 0;
    overflow: hidden;
     background-color: #56c6ca;
   
}
li{
    float: left;
}
#tab{
  display: block;
  color: white;
  padding: 20px;
  text-decoration: none; 
}

#tab:hover{
    background-color:#52b7bb; 
}

h1{
  text-align: center;
  font-family: Castellar; 
}

h2{
    text-align: center;
}




/* Link below is the reference page I used to assist me with the style of the Navbar  */
/* https://www.w3schools.com/css/tryit.asp?filename=trycss_navbar_horizontal_black */



</style>
