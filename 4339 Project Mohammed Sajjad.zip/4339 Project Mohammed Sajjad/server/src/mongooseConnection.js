const mongoose = require('mongoose'),
connectionUrl = 'mongodb://127.0.0.1:27017',
dbName = 'Cryo',
connectionString = connectionUrl + '/' + dbName
mongoose.connect(connectionString, 
    {useNewUrlParser: true,
     useUnifiedTopology: true, 
     useCreateIndex: true, 
     useFindAndModify: false});
const db = mongoose.connection 
db.on('error', console.error.bind(console, "Failed to connect"))
//This page is referenced to the class lecture from 11/11/20
module.exports = db;
