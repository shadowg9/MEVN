const mongoose = require('mongoose'),
validator = require('validator'),
jwt = require('jsonwebtoken')
bcrypt = require('bcryptjs')
//This page is referenced to the class lecture from 11/11/20
const userSchema = mongoose.Schema({
    firstName: {
        type: String,
        require: true,
        trim: true
    },
    lastName: {
        type: String,
        require: true,
        trim: true
    },
    dateofBirth: {
        type: String,
        require: true,
        trim: true
    },
    sex: {
        type: String,
        require: true,
        trim: true
    },
    email: {
        type: String,
        require: true,
        trim: true,
        unique: true,
        
    },
    password: {
        type: String,
        require: true,
        trim: true
    },
    tokens: [
        {
            token: {
                type: String,
                require: true
            }
        }
    ]
        
})

userSchema.pre("save", async function(next){
    const user = this
    if (user.isModified("password")){
        user.password = await brcypt.hash(user.password, 6)
    }
    next()
})

userSchema.methods.generateAuthToken = async function() {
    const user = this
    const token = jwt.sign({_id: user._id, name: user.lastName, email: user.email},
        "secret")
        user.tokens = user.tokens.concat({ token })
        await user.save()
        return token
    }

    const User = mongoose.model('User', userSchema)

    module.exports = User

