const { Router } = require('express')
const express = require('express'),
bodyParser = require('body-parser'),
methodOverride = require('method-override'),
cors = require('cors'),
logger = require('morgan')
PORT = process.env.PORT || 3001
mongo = require('./mongooseConnection')
const app = express()
app.use(express.static('public'))
app.use(logger('combined'))
app.use(bodyParser.urlencoded({extended: true}))
app.use(cors());
app.use(methodOverride('_method'))
app.use(express.json())





app.get('/', (req, res) => {
    var result = [];
    var momo = mongo.db.collection('userLogin').find();
    momo.forEach((doc, err) => {
        if (err) { throw err};
        result.push(doc); 
    },
    function() {
        console.log(result);
        res.send(result);
     
    } )
});

app.get('/cryo', (req, res) => {
    var result = [];
    var momo = mongo.db.collection('cryoData').find();
    momo.forEach((doc, err) => {
        if (err) { throw err};
        result.push(doc); 
    },
    function() {
        console.log(result);
        res.send(result);
     
    } )
});

app.post('/register',(req,res)=>{
    var newUser = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        dateofBirth: req.body.dateofBirth,
        sex: req.body.sex,
        email: req.body.email,
        password: req.body.password
    }
    mongo.db.collection('userLogin').insertOne(newUser,(err,result)=>{
        console.log.newUser
    });
    res.redirect('/')
}) 

app.post('/apply',(req,res)=>{
    var newCryo = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        startingDate: req.body.startingDate,
        endingDate: req.body.endingDate
    }
    mongo.db.collection('cryoData').insertOne(newCryo,(err,result)=>{
        console.log.newCryo
    });
    res.redirect('/')
}) 






app.listen(PORT, () => {
    console.log(`Managed on port ${PORT}`)
    console.log(`http://localhost:${PORT}`)
})

