const express = require('express'),
participantSchema = require('../model/user'),
bycrypt = require('bcryptjs')
//This page is referenced to the class lecture from 11/11/20
router = new express.Router 

router.post('/register', async (req, res) =>{
    console.log(req.body)
    const newParticipant = new participantSchema(req.body.participant)
    newParticipant.save().then(() => {
        res.send(newParticipant)
    }).catch((error) => {
        res.send(error)
    })
})

router.post("/login", async(req, res) => {
    try{
        console.log(req.body)
        const participant = req.body.participant
        console.log(participant)
        const email = participant.email
        const password = participant.password
        const foundUser = await participantSchema.findOne({email});
        if (!foundUser){
            throw new Error({error: "Invalid Login"});
        }
        const isValidPassword = await bycrypt.compare(password, foundUser.password);
        if (!isValidPassword){
            throw new Error({error: "Invalid Login"});
        }
        const token = await foundUser.generateAuthToken()
        res.send({foundUser, token})
    } catch(error){
        console.log(error)
        res.status(400).send()
    }
})

module.exports = router 